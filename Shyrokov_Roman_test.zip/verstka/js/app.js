const backButton = '<span class="slick-prev"><img src="images/left-arrow.webp" alt=""></span>';
const nextButton = '<span class="slick-next"><img src="images/right-arrow.webp" alt=""></span>'
$('.slick-slider').slick({ 
    dots: true, 
    infinite: true, 
    speed: 300, 
    slidesToShow: 1,
    prevArrow: backButton,
    nextArrow: nextButton
});